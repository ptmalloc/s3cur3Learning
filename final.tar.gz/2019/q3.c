/* sudo sysctl -w kernel.randomize_va_space=2 then ... */

#include <stdio.h>

#include <string.h>

short count;

int vul(int argc, char *argv[])

{

	unsigned char j;

	char pad[23];

	char b[29];



	printf("\n%x\n",&count);

	count = atoi(argv[1]);

	j = 4*count;





	memcpy(b, argv[2], j);

	if(j != (unsigned char)(4*count))

	{
		printf("Buffer Overflow!!");

		exit(1);

	}

	return 0;

}

int main(int argc, char *argv[])

{

	vul(argc,argv);

}



