
#include <stdio.h>
main(int argc,char **argv)
{
	 char buf[39];
 	 setreuid(0,0);
	 strncpy(buf,argv[1],38);
	 printf(buf);
	 printf("Win.\n");
 	 exit(0);
}

