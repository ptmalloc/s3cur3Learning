root:

tar -zpxvf final.tar.gz

sysctl -w kernel.randomize_va_space=0



1.(25 points)

2.(25 points) 
3.(25 points) //sysctl -w kernel.randomize_va_space=2 

4.(25 points) 

