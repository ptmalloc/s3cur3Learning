root:

tar -zpxvf final.tar.gz

sysctl -w kernel.randomize_va_space=0



1.(20 points)

2.(20 points) //sysctl -w kernel.randomize_va_space=2

3.(20 points) 

4.(20 points) 

5.(20 points)



6.(20 points) ***

