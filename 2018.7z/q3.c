/* sudo sysctl -w kernel.randomize_va_space=0 then ... */
#include <stdio.h>
#include <string.h>


int flag=0;

int vul(int argc, char **argv) 
{

        char buf[512];

        strncpy(buf, argv[1], sizeof(buf) - 1);

        printf("\n%x\n",&flag);

        printf(buf);

	if (flag==500) {
        system("ls");
        exit(1);
	}

        return 0;

}

int main(int argc, char *argv[])
{
	setenv ("PATH", "/bin:/usr/bin:/usr/local/bin", 1); 

	vul(argc,argv);
}

