/* sudo sysctl -w kernel.randomize_va_space=0 then ... */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern char **environ;
int i;
 
void func(char *b){
        char *blah=b;
        char bok[20];
 
        printf("%p\n",b);
        memset(bok, '\0', sizeof(bok));
        for(i=0; blah[i] != '\0'; i++)
                bok[i]=blah[i];
 
        printf("%s\n",bok);
}
 
int main(int argc, char **argv)
{
 
 	for(i = 0; environ[i] != NULL; i++)
		memset(environ[i], '\0', strlen(environ[i]));
		
        if(argc > 1)
                func(argv[1]);
        else
        printf("%s argument\n", argv[0]);
 
        return 0;
}
