/* sudo sysctl -w kernel.randomize_va_space=0 then ... */
/*User Return-to-libc to execute 
system("/usr/bin/who -m");
setreuid(0,0);
system("/usr/bin/id");
execl("/bin/sh","sh",NULL);
*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
int bof(FILE *badfile)
{
    char buffer[85];
    /* The following statement has a buffer overflow problem */
    fread(buffer, sizeof(char), 450, badfile);
    return 1;
}

int main(int argc, char **argv)
{
    FILE *badfile;
    badfile = fopen("badfile", "r");
    bof(badfile);
    printf("Returned Properly\n");
    fclose(badfile);
    return 1;
}

